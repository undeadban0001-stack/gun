
// commands/profile.js
module.exports = {{
    commands: ['profile'],
    run: async(sock, from, args, command) => {{
        await sock.sendMessage(from, {{ text: '✅ Command profile is ready! Add your own logic.' }})
    }}
}}
