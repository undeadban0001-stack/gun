
// commands/cards.js
module.exports = {{
    commands: ['cards'],
    run: async(sock, from, args, command) => {{
        await sock.sendMessage(from, {{ text: '✅ Command cards is ready! Add your own logic.' }})
    }}
}}
