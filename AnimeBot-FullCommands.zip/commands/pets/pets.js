
// commands/pets.js
module.exports = {{
    commands: ['pets'],
    run: async(sock, from, args, command) => {{
        await sock.sendMessage(from, {{ text: '✅ Command pets is ready! Add your own logic.' }})
    }}
}}
