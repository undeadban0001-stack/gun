
// commands/gangs.js
module.exports = {{
    commands: ['gangs'],
    run: async(sock, from, args, command) => {{
        await sock.sendMessage(from, {{ text: '✅ Command gangs is ready! Add your own logic.' }})
    }}
}}
