
// commands/economy.js
module.exports = {{
    commands: ['economy'],
    run: async(sock, from, args, command) => {{
        await sock.sendMessage(from, {{ text: '✅ Command economy is ready! Add your own logic.' }})
    }}
}}
