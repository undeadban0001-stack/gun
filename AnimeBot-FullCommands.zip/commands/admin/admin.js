
// commands/admin.js
module.exports = {{
    commands: ['admin'],
    run: async(sock, from, args, command) => {{
        await sock.sendMessage(from, {{ text: '✅ Command admin is ready! Add your own logic.' }})
    }}
}}
