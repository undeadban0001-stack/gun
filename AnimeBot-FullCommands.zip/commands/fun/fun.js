
// commands/fun.js
module.exports = {{
    commands: ['fun'],
    run: async(sock, from, args, command) => {{
        await sock.sendMessage(from, {{ text: '✅ Command fun is ready! Add your own logic.' }})
    }}
}}
