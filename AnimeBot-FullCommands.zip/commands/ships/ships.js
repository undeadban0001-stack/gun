
// commands/ships.js
module.exports = {{
    commands: ['ships'],
    run: async(sock, from, args, command) => {{
        await sock.sendMessage(from, {{ text: '✅ Command ships is ready! Add your own logic.' }})
    }}
}}
