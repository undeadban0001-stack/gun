
// AnimeBot - Full Commands Version (WhatsApp Node.js + Baileys + MongoDB)
const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys')
const mongoose = require('mongoose')
const fs = require('fs')
const pino = require('pino')
const config = require('./config.json')

async function connectToMongoDB() {
    try {
        await mongoose.connect(config.mongo_url, { useNewUrlParser: true, useUnifiedTopology: true })
        console.log("✅ Connected to MongoDB Atlas")
    } catch (err) {
        console.error("❌ MongoDB Error:", err)
    }
}

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info')
    const { version } = await fetchLatestBaileysVersion()
    const sock = makeWASocket({
        logger: pino({ level: 'silent' }),
        printQRInTerminal: true,
        auth: state,
        version
    })

    sock.ev.on('creds.update', saveCreds)

    sock.ev.on('messages.upsert', async (m) => {
        const msg = m.messages[0]
        if (!msg.message) return
        const from = msg.key.remoteJid
        const type = Object.keys(msg.message)[0]
        const body = type === 'conversation' ? msg.message.conversation : (type === 'extendedTextMessage' ? msg.message.extendedTextMessage.text : '')

        if (!body) return
        if (!body.startsWith(config.prefix)) return

        const args = body.slice(config.prefix.length).trim().split(/ +/)
        const command = args.shift().toLowerCase()

        // Load all command handlers dynamically
        const commandFiles = fs.readdirSync('./commands').filter(f => f.endsWith('.js'))
        for (const file of commandFiles) {
            try {
                const handler = require(`./commands/${file}`)
                if (handler.commands.includes(command)) {
                    handler.run(sock, from, args, command)
                }
            } catch (err) {
                console.log("Error loading command:", file, err)
            }
        }
    })
}

connectToMongoDB().then(startBot)
