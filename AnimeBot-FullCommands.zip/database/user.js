
// database/user.js
const mongoose = require('mongoose')

const userSchema = new mongoose.Schema({
    user_id: { type: String, required: true, unique: true },
    username: { type: String, default: "" },
    bio: { type: String, default: "" },
    age: { type: Number, default: 0 },
    profile_pic: { type: String, default: "" },
    wallet: { type: Number, default: 0 },
    bank: { type: Number, default: 0 },
    cards: { type: Array, default: [] },
    ships: { type: Array, default: [] },
    pets: { type: Array, default: [] },
    gang: { type: Object, default: null },
    country: { type: String, default: "" }
})

module.exports = mongoose.model('User', userSchema)
